#  Team-Mitglieder : Huang, Jin [an46ykim]; Liu, Peicheng [ha46tika]
class BaseLayer:
    def __init__(self):
        self.trainable = False
        self.weights = None

